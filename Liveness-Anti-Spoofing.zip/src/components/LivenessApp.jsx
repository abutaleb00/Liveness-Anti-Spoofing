import React, { useEffect, useRef, useState, useMemo } from "react"
import { motion, AnimatePresence } from "framer-motion"
import * as tf from "@tensorflow/tfjs"
import * as faceLandmarksDetection from "@tensorflow-models/face-landmarks-detection"
import { CFG, FRAMES } from "../config/livenessConfig"
import { UI } from "../config/uiStrings"
import { THEME } from "../config/themeConfig"

/* ----------------- utils ----------------- */
const dist = (a, b) => Math.hypot((a?.x||0) - (b?.x||0), (a?.y||0) - (b?.y||0))
const clamp = (v, min, max) => Math.max(min, Math.min(max, v))
const lerp = (a, b, t) => a + (b - a) * t
const scale01 = (x, lo, hi) => clamp((x - lo) / (hi - lo + 1e-12), 0, 1)
const percentile = (arr, p) => {
  const safe = arr.filter(Number.isFinite); if (!safe.length) return 0
  const a = [...safe].sort((x, y) => x - y)
  const idx = clamp((a.length - 1) * p, 0, a.length - 1)
  const lo = Math.floor(idx), hi = Math.ceil(idx), t = idx - lo
  return a[lo] * (1 - t) + a[hi] * t
}
function shuffle(arr) { const a = [...arr]; for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1));[a[i], a[j]] = [a[j], a[i]] } return a }

/* FaceMesh indices */
const IDX = {
  leftEyeOuter: 33, rightEyeOuter: 263,
  L: { left: 33, right: 133, top1: 159, top2: 160, bot1: 145, bot2: 144 },
  R: { left: 362, right: 263, top1: 386, top2: 385, bot1: 374, bot2: 380 },
  mouthLeft: 61, mouthRight: 291, mouthTop: 13, mouthBot: 14,
  cheekL: 234, cheekR: 454, noseTip: 4,
}
function eyeAspectRatio(pts, kp) {
  const p1 = pts[kp.left], p4 = pts[kp.right]
  const p2 = pts[kp.top1], p6 = pts[kp.bot1]
  const p3 = pts[kp.top2], p5 = pts[kp.bot2]
  const A = dist(p2, p6), B = dist(p3, p5), C = dist(p1, p4) + 1e-6
  return (A + B) / (2 * C)
}
function mouthAspectRatio(pts) {
  const vertical = dist(pts[IDX.mouthTop], pts[IDX.mouthBot])
  const horizontal = dist(pts[IDX.mouthLeft], pts[IDX.mouthRight]) + 1e-6
  return vertical / horizontal
}
function rawYaw(pts) {
  const L = pts[IDX.cheekL], R = pts[IDX.cheekR]
  if (!L || !R || typeof L.z !== "number" || typeof R.z !== "number") return 0
  return Math.atan2((L.z - R.z), Math.abs(R.x - L.x) + 1e-6)
}

/* ----------- depth features for PAD ----------- */
function planeResidualNorm(pts, keys, faceW) {
  const X = [], Z = []
  for (const k of keys) {
    const p = pts[k]; if (!p || typeof p.z !== "number") continue
    X.push([p.x / faceW, p.y / faceW, 1]); Z.push(p.z / faceW)
  }
  const n = X.length; if (n < 4) return 0
  const xtx = [[0, 0, 0], [0, 0, 0], [0, 0, 0]], xtz = [0, 0, 0]
  for (let i = 0; i < n; i++) {
    const [x, y, o] = X[i], z = Z[i]
    xtx[0][0] += x * x; xtx[0][1] += x * y; xtx[0][2] += x * o
    xtx[1][0] += y * x; xtx[1][1] += y * y; xtx[1][2] += y * o
    xtx[2][0] += o * x; xtx[2][1] += o * y; xtx[2][2] += o * o
    xtz[0] += x * z; xtz[1] += y * z; xtz[2] += o * z
  }
  const m = xtx
  const det = m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0])
  if (Math.abs(det) < 1e-9) return 0
  const inv = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
  inv[0][0] = (m[1][1] * m[2][2] - m[1][2] * m[2][1]) / det
  inv[0][1] = (m[0][2] * m[2][1] - m[0][1] * m[2][2]) / det
  inv[0][2] = (m[0][1] * m[1][2] - m[0][2] * m[1][1]) / det
  inv[1][0] = (m[1][2] * m[2][0] - m[1][0] * m[2][2]) / det
  inv[1][1] = (m[0][0] * m[2][2] - m[0][2] * m[2][0]) / det
  inv[1][2] = (m[0][2] * m[1][0] - m[0][0] * m[1][2]) / det
  inv[2][0] = (m[1][0] * m[2][1] - m[1][1] * m[2][0]) / det
  inv[2][1] = (m[0][1] * m[2][0] - m[0][0] * m[2][1]) / det
  inv[2][2] = (m[0][0] * m[1][1] - m[0][1] * m[1][0]) / det
  const beta = [
    inv[0][0] * xtz[0] + inv[0][1] * xtz[1] + inv[0][2] * xtz[2],
    inv[1][0] * xtz[0] + inv[1][1] * xtz[1] + inv[1][2] * xtz[2],
    inv[2][0] * xtz[0] + inv[2][1] * xtz[1] + inv[2][2] * xtz[2],
  ]
  let se = 0
  for (let i = 0; i < n; i++) {
    const [x, y, o] = X[i], z = Z[i]
    const zhat = beta[0] * x + beta[1] * y + beta[2] * o
    const r = z - zhat; se += r * r
  }
  const rmse = Math.sqrt(se / n)
  return Number.isFinite(rmse) ? rmse : 0
}
function extractDepthFeatures(pts) {
  const keys = [IDX.noseTip, IDX.cheekL, IDX.cheekR, IDX.leftEyeOuter, IDX.rightEyeOuter, IDX.mouthTop, IDX.mouthBot]
  const faceW = dist(pts[IDX.leftEyeOuter], pts[IDX.rightEyeOuter]) + 1e-6
  const Z = keys.map(k => pts[k]?.z).filter(z => typeof z === "number")
  if (Z.length < 4) return { zRangeN: 0, planeResN: 0, noseProtrusionN: 0 }
  const zRangeN = (Math.max(...Z) - Math.min(...Z)) / faceW
  const planeResN = planeResidualNorm(pts, keys, faceW)
  const nose = pts[IDX.noseTip].z, cheeks = (pts[IDX.cheekL].z + pts[IDX.cheekR].z) / 2
  const noseProtrusionN = Math.abs(nose - cheeks) / (Math.abs(Math.max(...Z) - Math.min(...Z)) + 1e-6)
  return {
    zRangeN: Number.isFinite(zRangeN) ? zRangeN : 0,
    planeResN: Number.isFinite(planeResN) ? planeResN : 0,
    noseProtrusionN: Number.isFinite(noseProtrusionN) ? noseProtrusionN : 0
  }
}

/* --------------- Bilingual UI text --------------- */
const INSTRUCTIONS = {
  blink: { en: "Please blink your eyes naturally 3 times (one after another)", bn: "অনুগ্রহ করে স্বাভাবিকভাবে ৩ বার চোখের পলক দিন (একের পর এক)", titleEn: "Blink", titleBn: "চোখের পলক", icon: "👀" },
  smile: { en: "Please smile naturally and hold for 1 second", bn: "অনুগ্রহ করে স্বাভাবিকভাবে হাসুন এবং ১ সেকেন্ড ধরে রাখুন", titleEn: "Smile!", titleBn: "হাসুন!", icon: "😊" },
  left:  { en: "Please turn your face CLEARLY to the left and hold for 2 seconds", bn: "অনুগ্রহ করে আপনার মুখ স্পষ্টভাবে বামে ঘুরান এবং ২ সেকেন্ড ধরে রাখুন", titleEn: "Turn Left ←", titleBn: "বামে তাকান ←", icon: "↩️" },
  right: { en: "Please turn your face CLEARLY to the right and hold for 2 seconds", bn: "অনুগ্রহ করে আপনার মুখ স্পষ্টভাবে ডানে ঘুরান এবং ২ সেকেন্ড ধরে রাখুন", titleEn: "Turn Right →", titleBn: "ডানে তাকান →", icon: "↪️" },
}
const STEP_BASE = ["left", "right", "smile", "blink"]

/* ---------- Smile helpers ---------- */
function mouthFeatures(pts) {
  const faceW = dist(pts[IDX.leftEyeOuter], pts[IDX.rightEyeOuter]) + 1e-6
  const wNorm = dist(pts[IDX.mouthLeft], pts[IDX.mouthRight]) / faceW
  const hNorm = dist(pts[IDX.mouthTop], pts[IDX.mouthBot]) / faceW
  const yCorners = (pts[IDX.mouthLeft].y + pts[IDX.mouthRight].y) / 2
  const yCenter = (pts[IDX.mouthTop].y + pts[IDX.mouthBot].y) / 2
  const curve = (yCenter - yCorners) / faceW
  return { wNorm, hNorm, curve }
}

/* ---------- Component ---------- */
export default function LivenessApp() {
  const videoRef = useRef(null)
  const canvasRef = useRef(null)
  const rafRef = useRef(0)
  const modelRef = useRef(null)

  const [modelReady, setModelReady] = useState(false)
  const [cameraOn, setCameraOn] = useState(false)
  const [cameraReady, setCameraReady] = useState(false)

  // phases: align -> calibrate -> run
  const [phase, setPhase] = useState("align")
  const phaseRef = useRef("align")
  useEffect(() => { phaseRef.current = phase }, [phase])

  const [currentStep, setCurrentStep] = useState(0)
  const [steps, setSteps] = useState(() => shuffle(STEP_BASE))
  const stepsRef = useRef(steps); useEffect(() => { stepsRef.current = steps }, [steps])
  const currentStepRef = useRef(0)

  const [calibPct, setCalibPct] = useState(0)
  const [holdPct, setHoldPct] = useState(0)
  const [blinkCount, setBlinkCount] = useState(0)
  const [livenessScore, setLivenessScore] = useState(0)
  const [spoofScore, setSpoofScore] = useState(0)
  const [finalPass, setFinalPass] = useState(null)
  const finalPassRef = useRef(null); useEffect(() => { finalPassRef.current = finalPass }, [finalPass])
  const [error, setError] = useState("")
  const [faceCount, setFaceCount] = useState(0)
  const [photo, setPhoto] = useState(null)
  const [guide, setGuide] = useState({ titleEn: "", titleBn: "", en: "", bn: "", severity: "progress", icon: "ℹ️" })

  const blinkRef = useRef(0)
  const blinkTargetRef = useRef(3)
  const smooth = useRef({ EAR: 0, MAR: 0, YAW: 0, depthVar: 0, WNORM: 0, HNORM: 0, CURVE: 0 })

  const lastBBoxRef = useRef(null) // for passport crop

  const stateRef = useRef({
    prevEyesClosed: false,
    holdFrames: 0,
    depthSamples: [],
    // alignment
    alignHold: 0,
    alignOk: false,

    calib: { samples: 0, secs: 0, earSum: 0, marSum: 0, mwSum: 0, curveSum: 0, ear: 0, mar: 0, mwBase: 0, curveBase: 0, EAR_OPEN_DYN: 0.21, EAR_CLOSED_DYN: 0.17 },

    stepStartTime: performance.now(),
    stepStartBlink: 0,
    latencies: [],

    blinkAmps: [], lastOpenEAR: 0, closing: false, minEAR: 1, lastBlinkTs: 0,
    holdGoodFrames: 0, holdTotalFrames: 0,

    passed: { left: false, right: false, smile: false, blink: false },

    postCapture: { pending: false, due: 0, hold: 0, taken: false },
  })

  const finalizeScheduledRef = useRef(false)
  const freezeLiveRef = useRef(false)

  const cfg = useMemo(() => ({
    EAR_OPEN: CFG.EAR_OPEN,
    EAR_CLOSED: CFG.EAR_CLOSED,

    MAR_SMILE: CFG.MAR_SMILE,
    SMILE_MAR_DELTA: CFG.SMILE_MAR_DELTA,
    SMILE_W_DELTA: CFG.SMILE_W_DELTA,
    SMILE_CURVE_DELTA: CFG.SMILE_CURVE_DELTA,
    SMILE_MAR_DELTA2: CFG.SMILE_MAR_DELTA2,

    YAW_FLIP: CFG.YAW_FLIP,
    YAW_RAD: CFG.YAW_RAD,
    YAW_MARGIN: CFG.YAW_MARGIN,

    RESPONSE_MIN_S: CFG.RESPONSE_MIN_S,
    RESPONSE_MAX_S: CFG.RESPONSE_MAX_S,
    MIN_STEP_TIME_S: CFG.MIN_STEP_TIME_S,

    HOLD_FRAMES_TURN: FRAMES.HOLD_FRAMES_TURN,
    HOLD_FRAMES: FRAMES.HOLD_FRAMES,

    BLINK_AMP_GOOD: [CFG.BLINK_AMP_GOOD_LOW, CFG.BLINK_AMP_GOOD_HIGH],

    ZRANGE_GOOD: [CFG.ZRANGE_GOOD_LO, CFG.ZRANGE_GOOD_HI],
    PLANE_GOOD: [CFG.PLANE_GOOD_LO, CFG.PLANE_GOOD_HI],
    NOSE_GOOD: [CFG.NOSE_GOOD_LO, CFG.NOSE_GOOD_HI],

    CALIB_SECONDS: CFG.CALIB_SECONDS,

    NEUTRAL_CAPTURE_DELAY_MS: CFG.NEUTRAL_CAPTURE_DELAY_MS,
    NEUTRAL_YAW: CFG.NEUTRAL_YAW,
    NEUTRAL_MAR_DELTA: CFG.NEUTRAL_MAR_DELTA,
    NEUTRAL_TIMEOUT_MS: CFG.NEUTRAL_TIMEOUT_MS,
    NEUTRAL_HOLD_FRAMES: CFG.NEUTRAL_HOLD_FRAMES,

    PASS_THRESH_LIVE: CFG.PASS_THRESH_LIVE,
    PASS_THRESH_PAD: CFG.PASS_THRESH_PAD,

    // Face alignment
    FACE_ALIGN_ENABLED: CFG.FACE_ALIGN_ENABLED,
    FACE_ALIGN_RADIUS_RATIO: CFG.FACE_ALIGN_RADIUS_RATIO,
    FACE_ALIGN_CENTER_TOL_RATIO: CFG.FACE_ALIGN_CENTER_TOL_RATIO,
    FACE_ALIGN_EYE_DIST_MIN: CFG.FACE_ALIGN_EYE_DIST_MIN,
    FACE_ALIGN_EYE_DIST_MAX: CFG.FACE_ALIGN_EYE_DIST_MAX,
    FACE_ALIGN_YAW_MAX: CFG.FACE_ALIGN_YAW_MAX,
    FACE_ALIGN_HOLD_FRAMES: CFG.FACE_ALIGN_HOLD_FRAMES,
  }), [])

  /* model load */
  useEffect(() => {
    (async () => {
      try {
        await tf.ready()
        if (tf.backend().name !== "webgl") { try { await tf.setBackend("webgl"); await tf.ready() } catch { } }
        const model = await faceLandmarksDetection.createDetector(
          faceLandmarksDetection.SupportedModels.MediaPipeFaceMesh,
          { runtime: "mediapipe", refineLandmarks: true, solutionPath: "https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh" }
        )
        modelRef.current = model
        setModelReady(true)
      } catch (e) { console.error(e); setError(String(e)) }
    })()
    return () => cancelAnimationFrame(rafRef.current)
  }, [])

  /* camera control */
  async function startCamera() {
    try {
      if (!modelReady) return
      const v = videoRef.current
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user", width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false })
      v.srcObject = stream
      setCameraReady(false); await v.play()
      setCameraOn(true); setCameraReady(true)
      hardReset(); setPhase(cfg.FACE_ALIGN_ENABLED ? "align" : "calibrate")
    } catch (e) { console.error(e); setError(String(e)) }
  }
  async function stopCamera() {
    try {
      const v = videoRef.current
      const stream = v?.srcObject
      if (stream) stream.getTracks().forEach(t => t.stop())
      if (v) v.srcObject = null
      cancelAnimationFrame(rafRef.current)
      setCameraOn(false); setCameraReady(false); setFaceCount(0)
      hardReset()
      const c = canvasRef.current; if (c) { const ctx = c.getContext("2d"); ctx.clearRect(0, 0, c.width, c.height) }
    } catch (e) { console.error(e); setError(String(e)) }
  }
  function restart() { if (cameraOn) softReset() }

  /* resets */
  function softReset() {
    const newSteps = shuffle(STEP_BASE)
    setSteps(newSteps); stepsRef.current = newSteps
    setCurrentStep(0); currentStepRef.current = 0
    setHoldPct(0); setBlinkCount(0)
    setLivenessScore(0); setSpoofScore(0); setFinalPass(null); finalPassRef.current = null
    setPhoto(null)
    blinkRef.current = 0; blinkTargetRef.current = CFG.BLINK_TARGET_MIN + Math.floor(Math.random() * (CFG.BLINK_TARGET_MAX - CFG.BLINK_TARGET_MIN + 1))
    const st = stateRef.current
    Object.assign(st, {
      prevEyesClosed: false, holdFrames: 0, depthSamples: [],
      alignHold: 0, alignOk: false,
      calib: { samples: 0, secs: 0, earSum: 0, marSum: 0, mwSum: 0, curveSum: 0, ear: 0, mar: 0, mwBase: 0, curveBase: 0, EAR_OPEN_DYN: 0.21, EAR_CLOSED_DYN: 0.17 },
      stepStartTime: performance.now(), stepStartBlink: 0, latencies: [],
      blinkAmps: [], lastOpenEAR: 0, closing: false, minEAR: 1, lastBlinkTs: 0,
      holdGoodFrames: 0, holdTotalFrames: 0,
      passed: { left: false, right: false, smile: false, blink: false },
      postCapture: { pending: false, due: 0, hold: 0, taken: false },
    })
    setPhase(cfg.FACE_ALIGN_ENABLED ? "align" : "calibrate")
    finalizeScheduledRef.current = false
    freezeLiveRef.current = false
  }
  function hardReset() {
    softReset()
  }

  /* ----- PAD + reasons ----- */
  function computePadFromSamples(st) {
    const arr = st.depthSamples
    let depthScore = 0
    if (arr.length >= 12) {
      const zRangeN_p75 = percentile(arr.map(o => o.zRangeN), 0.75)
      const planeN_p25 = percentile(arr.map(o => o.planeResN), 0.25)
      const noseN_p50 = percentile(arr.map(o => o.noseProtrusionN), 0.50)

      const sZ = scale01(zRangeN_p75, cfg.ZRANGE_GOOD[0], cfg.ZRANGE_GOOD[1])
      const sPlan = scale01(planeN_p25, cfg.PLANE_GOOD[0], cfg.PLANE_GOOD[1])
      const sNose = scale01(noseN_p50, cfg.NOSE_GOOD[0], cfg.NOSE_GOOD[1])

      depthScore = (0.5 * sZ + 0.3 * sPlan + 0.2 * sNose) * 100
    }

    const totalSteps = 4
    const passedSteps = ["left", "right", "smile", "blink"].reduce((a, k) => a + (st.passed[k] ? 1 : 0), 0)
    const actionQuality = (passedSteps / totalSteps) * 100

    const timely = st.latencies.filter(t => t >= cfg.RESPONSE_MIN_S && t <= cfg.RESPONSE_MAX_S).length
    const respScore = (st.latencies.length > 0) ? (timely / st.latencies.length) * 100 : 0

    const pad = CFG.PAD_W_DEPTH * depthScore + CFG.PAD_W_RESP * respScore + CFG.PAD_W_ACTION * actionQuality
    return Math.round(Number.isFinite(pad) ? pad : 0)
  }
  function padReasons(st) {
    const arr = st.depthSamples; const reasons = []
    if (arr.length >= 12) {
      const zRangeN_p75 = percentile(arr.map(o => o.zRangeN), 0.75)
      const planeN_p25 = percentile(arr.map(o => o.planeResN), 0.25)
      const noseN_p50 = percentile(arr.map(o => o.noseProtrusionN), 0.50)
      if (zRangeN_p75 < cfg.ZRANGE_GOOD[0]) reasons.push("Flat depth (possible screen)")
      if (planeN_p25 < cfg.PLANE_GOOD[0]) reasons.push("Near-planar surface")
      if (noseN_p50 < cfg.NOSE_GOOD[0]) reasons.push("Weak nose protrusion")
    }
    const timely = st.latencies.filter(t => t >= cfg.RESPONSE_MIN_S && t <= cfg.RESPONSE_MAX_S).length
    if (st.latencies.length > 0 && (timely / st.latencies.length) < 0.7) reasons.push("Prompt timing mismatch")
    return reasons
  }

  /* ---------- Continuous liveness ---------- */
  function computeLivenessComposite(st) {
    const totalSteps = 4
    const passedSteps = ["left", "right", "smile", "blink"].reduce((a, k) => a + (st.passed[k] ? 1 : 0), 0)
    let progressCurrent = 0
    const step = stepsRef.current[currentStepRef.current]
    if (phaseRef.current !== "run") return 0
    if (step) {
      if (step === "blink") {
        const blinksInStep = blinkRef.current - st.stepStartBlink
        const target = blinkTargetRef.current || CFG.BLINK_TARGET_MIN
        progressCurrent = clamp(blinksInStep / target, 0, 1)
      } else {
        progressCurrent = clamp(holdPct / 100, 0, 1)
      }
    }
    const stepScore = ((passedSteps + progressCurrent) / totalSteps) * 100

    const timely = st.latencies.filter(t => t >= cfg.RESPONSE_MIN_S && t <= cfg.RESPONSE_MAX_S).length
    const timingScore = (st.latencies.length > 0) ? (timely / st.latencies.length) * 100 : 65

    let blinkScore = 60
    if (st.blinkAmps.length) {
      const med = percentile(st.blinkAmps, 0.5)
      blinkScore = scale01(med, cfg.BLINK_AMP_GOOD[0], cfg.BLINK_AMP_GOOD[1]) * 100
    }

    const smoothness = st.holdTotalFrames ? (st.holdGoodFrames / st.holdTotalFrames) : 0.65
    const smoothnessScore = smoothness * 100

    const live = CFG.LIVE_W_STEP * stepScore + CFG.LIVE_W_TIMING * timingScore + CFG.LIVE_W_BLINK * blinkScore + CFG.LIVE_W_SMOOTH * smoothnessScore
    return Math.round(clamp(live, 0, 100))
  }

  /* -------- RAF loop -------- */
  useEffect(() => {
    if (!cameraOn) return
    let last = performance.now()
    const loop = async () => {
      const now = performance.now()
      const dt = (now - last) / 1000; last = now
      await tick()
      if (!freezeLiveRef.current) setLivenessScore(computeLivenessComposite(stateRef.current))
      rafRef.current = requestAnimationFrame(loop)
    }
    rafRef.current = requestAnimationFrame(loop)
    return () => cancelAnimationFrame(rafRef.current)
  }, [cameraOn])

  /* -------- main tick -------- */
  async function tick() {
    const v = videoRef.current, c = canvasRef.current
    if (!v || !c || !modelRef.current || v.readyState < 2) return
    const ctx = c.getContext("2d")
    c.width = v.videoWidth; c.height = v.videoHeight

    const faces = await modelRef.current.estimateFaces(v, { flipHorizontal: true })
    ctx.drawImage(v, 0, 0, c.width, c.height)

    const nFaces = faces?.length || 0; if (nFaces !== faceCount) setFaceCount(nFaces)
    if (!faces || faces.length === 0) {
      if (cfg.FACE_ALIGN_ENABLED && phaseRef.current === "align") drawFaceGuide(ctx, false, 0, getCircleSpec(c))
      return
    }

    const face = faces[0]
    const pts2D = face.keypoints
    const pts = face.keypoints3D ?? face.keypoints

    // bbox for passport capture
    if (pts2D && pts2D.length) {
      let minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9
      for (const p of pts2D) { if (p.x < minX) minX = p.x; if (p.y < minY) minY = p.y; if (p.x > maxX) maxX = p.x; if (p.y > maxY) maxY = p.y }
      lastBBoxRef.current = { x: minX, y: minY, w: maxX - minX, h: maxY - minY }
    }

    const EAR = (eyeAspectRatio(pts, IDX.L) + eyeAspectRatio(pts, IDX.R)) / 2
    const MAR = mouthAspectRatio(pts)
    const YAW = (cfg.YAW_FLIP ? -1 : 1) * rawYaw(pts)
    const { wNorm, hNorm, curve } = mouthFeatures(pts)

    const a = 0.2
    smooth.current.EAR = lerp(smooth.current.EAR || EAR, EAR, a)
    smooth.current.MAR = lerp(smooth.current.MAR || MAR, MAR, a)
    smooth.current.YAW = lerp(smooth.current.YAW || YAW, YAW, a)
    smooth.current.WNORM = lerp(smooth.current.WNORM || wNorm, wNorm, a)
    smooth.current.HNORM = lerp(smooth.current.HNORM || hNorm, hNorm, a)
    smooth.current.CURVE = lerp(smooth.current.CURVE || curve, curve, a)

    // Phase: ALIGN — draw face circle and gate
    if (cfg.FACE_ALIGN_ENABLED && phaseRef.current === "align") {
      const spec = getCircleSpec(c)
      const ok = checkAlignment(spec, pts2D, YAW)
      const st = stateRef.current
      if (ok) st.alignHold = Math.min(cfg.FACE_ALIGN_HOLD_FRAMES, st.alignHold + 1)
      else st.alignHold = Math.max(0, st.alignHold - 1)
      const pct = clamp((st.alignHold / cfg.FACE_ALIGN_HOLD_FRAMES), 0, 1)
      drawFaceGuide(ctx, ok, pct, spec)

      if (st.alignHold >= cfg.FACE_ALIGN_HOLD_FRAMES) {
        setPhase("calibrate")
        return
      }
      return
    }

    drawMesh(ctx, face)

    // calibration
    if (phaseRef.current === "calibrate") {
      const st = stateRef.current
      st.calib.samples += 1; st.calib.secs += (1 / 60)
      st.calib.earSum += smooth.current.EAR
      st.calib.marSum += smooth.current.MAR
      st.calib.mwSum += smooth.current.WNORM
      st.calib.curveSum += smooth.current.CURVE

      const pct = Math.min(100, Math.round((st.calib.secs / cfg.CALIB_SECONDS) * 100)); setCalibPct(pct)
      if (st.calib.secs >= cfg.CALIB_SECONDS) {
        st.calib.ear = st.calib.earSum / st.calib.samples
        st.calib.mar = st.calib.marSum / st.calib.samples
        st.calib.mwBase = st.calib.mwSum / st.calib.samples
        st.calib.curveBase = st.calib.curveSum / st.calib.samples
        st.calib.EAR_CLOSED_DYN = Math.max(cfg.EAR_CLOSED, st.calib.ear - 0.06)
        st.calib.EAR_OPEN_DYN = Math.max(cfg.EAR_OPEN, st.calib.ear - 0.02)
        setPhase("run")
        st.stepStartTime = performance.now()
        st.stepStartBlink = blinkRef.current
        blinkTargetRef.current = CFG.BLINK_TARGET_MIN + Math.floor(Math.random() * (CFG.BLINK_TARGET_MAX - CFG.BLINK_TARGET_MIN + 1))
      }
      return
    }

    // RUN
    updateBlink(EAR)
    updateStepProgress()
    updateDepthSamples(pts)
    setSpoofScore(computePadFromSamples(stateRef.current))

    const st = stateRef.current
    const done = currentStepRef.current >= stepsRef.current.length
    if (done && st.postCapture.pending && !st.postCapture.taken) {
      const now = performance.now()
      const due = st.postCapture.due
      if (now >= due) {
        const neutralYaw = Math.abs(smooth.current.YAW) < cfg.NEUTRAL_YAW
        const neutralSmile = (smooth.current.MAR < st.calib.mar + cfg.NEUTRAL_MAR_DELTA)
        const eyesOk = smooth.current.EAR > (st.calib.ear - 0.03)
        if (neutralYaw && neutralSmile && eyesOk) {
          st.postCapture.hold++
          if (st.postCapture.hold >= cfg.NEUTRAL_HOLD_FRAMES) {
            const shot = await capturePassport()
            setPhoto(shot?.data_url || null)
            st.postCapture.taken = true
          }
        } else {
          st.postCapture.hold = Math.max(0, st.postCapture.hold - 1)
          if (now - due > cfg.NEUTRAL_TIMEOUT_MS) {
            const shot = await capturePassport()
            setPhoto(shot?.data_url || null)
            st.postCapture.taken = true
          }
        }
      }
    }
  }

  function updateBlink(EAR) {
    const st = stateRef.current
    const eyesClosed = EAR < (st.calib?.EAR_CLOSED_DYN ?? cfg.EAR_CLOSED)
    const reOpen = EAR > (st.calib?.EAR_OPEN_DYN ?? cfg.EAR_OPEN)

    if (!eyesClosed) st.lastOpenEAR = EAR

    if (eyesClosed && !st.prevEyesClosed) { st.prevEyesClosed = true; st.closing = true; st.minEAR = EAR }
    else if (eyesClosed && st.closing) { if (EAR < st.minEAR) st.minEAR = EAR }

    if (st.prevEyesClosed && reOpen) {
      st.prevEyesClosed = false
      if (st.closing) {
        const open = st.lastOpenEAR || st.calib.ear || EAR
        const amp = Math.max(0, open - st.minEAR)
        const now = performance.now(); const dt = now - (st.lastBlinkTs || 0)
        if (amp >= CFG.BLINK_MIN_AMP && dt >= CFG.BLINK_MIN_INTERVAL_MS) {
          st.blinkAmps.push(amp); if (st.blinkAmps.length > 20) st.blinkAmps.shift()
          st.lastBlinkTs = now
          blinkRef.current += 1; setBlinkCount(b => b + 1)
        }
      }
      st.closing = false
    }
  }

  function getHoldFramesForStep(step) { return (step === "left" || step === "right") ? cfg.HOLD_FRAMES_TURN : cfg.HOLD_FRAMES }

  function updateStepProgress() {
    const st = stateRef.current
    const step = stepsRef.current[currentStepRef.current]
    if (!step) return

    const timeSinceStart = (performance.now() - st.stepStartTime) / 1000
    const minGate = Math.max(cfg.RESPONSE_MIN_S, cfg.MIN_STEP_TIME_S)

    let ok = false
    if (step === "left") { ok = smooth.current.YAW > (cfg.YAW_RAD + cfg.YAW_MARGIN) }
    else if (step === "right") { ok = smooth.current.YAW < -(cfg.YAW_RAD + cfg.YAW_MARGIN) }
    else if (step === "smile") {
      const wDelta = (smooth.current.WNORM || 0) - (st.calib.mwBase || 0)
      const curveDelta = (smooth.current.CURVE || 0) - (st.calib.curveBase || 0)
      const marDelta = (smooth.current.MAR || 0) - (st.calib.mar || 0)
      ok = wDelta >= cfg.SMILE_W_DELTA || curveDelta >= cfg.SMILE_CURVE_DELTA || marDelta >= cfg.SMILE_MAR_DELTA2 || (smooth.current.MAR || 0) > Math.max(cfg.MAR_SMILE, st.calib.mar + cfg.SMILE_MAR_DELTA)
    } else if (step === "blink") {
      const blinksInStep = blinkRef.current - st.stepStartBlink
      const target = blinkTargetRef.current || CFG.BLINK_TARGET_MIN
      setHoldPct(clamp((blinksInStep / target) * 100, 0, 100))
      if (blinksInStep >= target && timeSinceStart >= minGate) {
        st.passed.blink = true
        const latency = (performance.now() - st.stepStartTime) / 1000
        st.latencies.push(latency)
        nextStep()
      }
      return
    }

    if (ok) st.holdGoodFrames++
    st.holdTotalFrames++

    const neededHold = getHoldFramesForStep(step)
    if (timeSinceStart < minGate) { setHoldPct(clamp((st.holdFrames / neededHold) * 100, 0, 100)); return }

    if (ok) st.holdFrames++
    else st.holdFrames = Math.max(0, st.holdFrames - 1)

    setHoldPct(clamp((st.holdFrames / neededHold) * 100, 0, 100))

    if (st.holdFrames >= neededHold) {
      st.holdFrames = 0
      st.passed[step] = true
      const latency = (performance.now() - st.stepStartTime) / 1000
      st.latencies.push(latency)
      nextStep()
    }
  }

  function nextStep() {
    const st = stateRef.current
    currentStepRef.current += 1
    setCurrentStep(i => {
      const n = i + 1
      if (n >= stepsRef.current.length) {
        const pass = (computePadFromSamples(st) >= cfg.PASS_THRESH_PAD) && (computeLivenessComposite(st) >= cfg.PASS_THRESH_LIVE)
        setFinalPass(pass); finalPassRef.current = pass; freezeLiveRef.current = true; setLivenessScore(computeLivenessComposite(st))
        st.postCapture = { pending: true, due: performance.now() + cfg.NEUTRAL_CAPTURE_DELAY_MS, hold: 0, taken: false }
        scheduleFinalizeResults()
      } else {
        st.stepStartTime = performance.now()
        st.stepStartBlink = blinkRef.current
        st.holdFrames = 0
      }
      return n
    })
  }

  function scheduleFinalizeResults() {
    if (finalizeScheduledRef.current) return
    finalizeScheduledRef.current = true
    setTimeout(() => {
      const st = stateRef.current
      const padNow = computePadFromSamples(st)
      setSpoofScore(padNow)
      const passNow = padNow >= cfg.PASS_THRESH_PAD && (computeLivenessComposite(st) >= cfg.PASS_THRESH_LIVE)
      setFinalPass(passNow); finalPassRef.current = passNow
    }, 700)
  }

  function updateDepthSamples(pts) {
    const f = extractDepthFeatures(pts)
    stateRef.current.depthSamples.push(f)
    if (stateRef.current.depthSamples.length > 200) stateRef.current.depthSamples.shift()
    smooth.current.depthVar = f.zRangeN
  }

  /* ------------- drawing / overlays ------------- */
  function drawMesh(ctx, face) {
    const kp = face.keypoints
    ctx.save()
    ctx.fillStyle = "rgba(45,212,191,0.5)"
    for (let i = 0; i < kp.length; i += 8) { const p = kp[i]; ctx.beginPath(); ctx.arc(p.x, p.y, 1.6, 0, Math.PI * 2); ctx.fill() }
    ctx.restore()
  }

  // ALIGNMENT: circle spec & checks
  function getCircleSpec(c) {
    const w = c.width, h = c.height
    const s = Math.min(w, h)
    const r = s * cfg.FACE_ALIGN_RADIUS_RATIO
    const cx = Math.round(w / 2)
    const cy = Math.round(h * 0.42) // slightly higher than center
    return { cx, cy, r, w, h }
  }
  function checkAlignment(spec, keypoints2D, yaw) {
    if (!keypoints2D || keypoints2D.length < 300) return false
    const leftEye = keypoints2D[IDX.leftEyeOuter]
    const rightEye = keypoints2D[IDX.rightEyeOuter]
    const nose = keypoints2D[IDX.noseTip]
    const eyeDist = dist(leftEye, rightEye)
    const box = lastBBoxRef.current
    const faceCx = (box?.x || nose?.x || spec.cx), faceCy = (box?.y || nose?.y || spec.cy) + (box?.h ? box.h * 0.45 : 0) // bias downward
    const d = Math.hypot(faceCx - spec.cx, faceCy - spec.cy)
    const centerOk = d <= (spec.r * cfg.FACE_ALIGN_CENTER_TOL_RATIO)
    const dia = spec.r * 2
    const eyeRatio = eyeDist / (dia + 1e-6)
    const sizeOk = eyeRatio >= cfg.FACE_ALIGN_EYE_DIST_MIN && eyeRatio <= cfg.FACE_ALIGN_EYE_DIST_MAX
    const yawOk = Math.abs(yaw) <= cfg.FACE_ALIGN_YAW_MAX
    stateRef.current.alignOk = centerOk && sizeOk && yawOk
    return stateRef.current.alignOk
  }
  function drawFaceGuide(ctx, ok, pct, spec) {
    const ring = ok ? THEME.ok.ring : THEME.idle.ring
    const maskBg = THEME.idle.bg
    ctx.save()
    // Dim background
    ctx.fillStyle = maskBg
    ctx.fillRect(0, 0, spec.w, spec.h)
    // Punch circle
    ctx.globalCompositeOperation = "destination-out"
    ctx.beginPath(); ctx.arc(spec.cx, spec.cy, spec.r, 0, Math.PI * 2); ctx.fill()
    ctx.globalCompositeOperation = "source-over"
    // Stroke ring
    ctx.lineWidth = Math.max(3, spec.r * 0.04)
    ctx.strokeStyle = ring
    ctx.beginPath(); ctx.arc(spec.cx, spec.cy, spec.r, 0, Math.PI * 2); ctx.stroke()
    // Progress arc
    if (pct > 0) {
      ctx.strokeStyle = THEME.ok.ring
      ctx.lineCap = "round"
      ctx.beginPath()
      ctx.arc(spec.cx, spec.cy, spec.r, -Math.PI/2, -Math.PI/2 + (Math.PI*2)*pct, false)
      ctx.stroke()
    }
    // Labels
    ctx.fillStyle = "#e2e8f0"
    ctx.font = "16px system-ui"
    ctx.textAlign = "center"
    const en = ok ? UI.align.okEn : UI.align.en
    const bn = ok ? UI.align.okBn : UI.align.bn
    ctx.fillText(en, spec.cx, spec.cy + spec.r + 28)
    ctx.fillText(bn, spec.cx, spec.cy + spec.r + 46)
    ctx.restore()
  }

  /* ---------- Passport capture (no UI overlays) ---------- */
  async function capturePassport() {
    const v = videoRef.current
    if (!v || v.readyState < 2) return { data_url: null, base64: null }
    const frame = await grabBestFrameCanvas(v)
    const ow = frame.width, oh = frame.height
    const box = lastBBoxRef.current || { x: ow * 0.25, y: oh * 0.20, w: ow * 0.50, h: oh * 0.60 }
    const padLeft = box.w * 0.50, padRight = box.w * 0.50, padTop = box.h * 1.00, padBottom = box.h * 0.60
    let sx = Math.max(0, Math.floor(box.x - padLeft))
    let sy = Math.max(0, Math.floor(box.y - padTop))
    let sw = Math.min(ow - sx, Math.ceil(box.w + padLeft + padRight))
    let sh = Math.min(oh - sy, Math.ceil(box.h + padTop + padBottom))
    const targetAR = 3 / 4, curAR = sw / sh
    if (curAR > targetAR) { const newH = Math.round(sw / targetAR); const delta = newH - sh; sy = Math.max(0, sy - Math.round(delta * 0.60)); sh = Math.min(oh - sy, newH) }
    else { const newW = Math.round(sh * targetAR); const delta = newW - sw; sx = Math.max(0, sx - Math.round(delta / 2)); sw = Math.min(ow - sx, newW) }
    const outW = 900, outH = 1200
    const out = document.createElement("canvas"); out.width = outW; out.height = outH
    const outctx = out.getContext("2d")
    outctx.imageSmoothingEnabled = true; outctx.imageSmoothingQuality = "high"
    outctx.drawImage(frame, sx, sy, sw, sh, 0, 0, outW, outH)
    enhanceCanvasInPlace(outctx, outW, outH)
    const dataUrl = out.toDataURL("image/jpeg", 0.96)
    return { data_url: dataUrl, base64: dataUrl.split(",")[1] }
  }

  async function grabBestFrameCanvas(video) {
    const makeCanvas = (w, h) => { const c = document.createElement("canvas"); c.width = w; c.height = h; return c }
    try {
      const track = video.srcObject?.getVideoTracks?.()[0]
      if (track && "ImageCapture" in window) {
        const ic = new window.ImageCapture(track)
        const bmp = await ic.grabFrame()
        const c = makeCanvas(bmp.width, bmp.height)
        const cx = c.getContext("2d")
        cx.save(); cx.translate(c.width, 0); cx.scale(-1, 1); cx.drawImage(bmp, 0, 0); cx.restore()
        return c
      }
    } catch {}
    const c = makeCanvas(video.videoWidth, video.videoHeight)
    const cx = c.getContext("2d")
    cx.save(); cx.translate(c.width, 0); cx.scale(-1, 1); cx.drawImage(video, 0, 0); cx.restore()
    return c
  }

  function enhanceCanvasInPlace(ctx, w, h) {
    const img = ctx.getImageData(0, 0, w, h)
    const d = img.data; const n = d.length
    let rSum = 0, gSum = 0, bSum = 0, count = n / 4
    for (let i = 0; i < n; i += 4) { rSum += d[i]; gSum += d[i + 1]; bSum += d[i + 2] }
    const rMean = rSum / count, gMean = gSum / count, bMean = bSum / count
    const avg = (rMean + gMean + bMean) / 3 || 1
    const gR = avg / (rMean || 1), gG = avg / (gMean || 1), gB = avg / (bMean || 1)

    const hist = new Uint32Array(256)
    for (let i = 0; i < n; i += 4) {
      let r = clamp(Math.round(d[i] * gR), 0, 255)
      let g = clamp(Math.round(d[i + 1] * gG), 0, 255)
      let b = clamp(Math.round(d[i + 2] * gB), 0, 255)
      d[i] = r; d[i + 1] = g; d[i + 2] = b
      const y = Math.round(0.2126 * r + 0.7152 * g + 0.0722 * b)
      hist[y]++
    }
    const total = count
    const lowCut = Math.round(total * 0.02), highCut = Math.round(total * 0.98)
    let acc = 0, low = 0, high = 255
    for (let v = 0; v < 256; v++) { acc += hist[v]; if (acc >= lowCut) { low = v; break } }
    acc = 0
    for (let v = 255; v >= 0; v--) { acc += hist[v]; if (acc >= total - highCut) { high = v; break } }
    const eps = Math.max(1, high - low)
    const gain = 255 / eps, bias = -low * gain
    const gamma = 0.95
    for (let i = 0; i < n; i += 4) {
      let r = clamp((d[i] * gain + bias), 0, 255)
      let g = clamp((d[i + 1] * gain + bias), 0, 255)
      let b = clamp((d[i + 2] * gain + bias), 0, 255)
      d[i] = Math.round(255 * Math.pow(r / 255, gamma))
      d[i + 1] = Math.round(255 * Math.pow(g / 255, gamma))
      d[i + 2] = Math.round(255 * Math.pow(b / 255, gamma))
    }
    ctx.putImageData(img, 0, 0)

    const src = ctx.getImageData(0, 0, w, h)
    const sb = src.data
    const blur = new Uint8ClampedArray(sb.length)
    const k = [1, 2, 1, 2, 4, 2, 1, 2, 1]
    for (let yy = 1; yy < h - 1; yy++) {
      for (let xx = 1; xx < w - 1; xx++) {
        let r = 0, g = 0, b = 0, ki = 0
        for (let j = -1; j <= 1; j++) {
          for (let i = -1; i <= 1; i++) {
            const idx = ((yy + j) * w + (xx + i)) << 2
            const kv = k[ki++]
            r += sb[idx] * kv
            g += sb[idx + 1] * kv
            b += sb[idx + 2] * kv
          }
        }
        const o = (yy * w + xx) << 2
        blur[o] = r >> 4; blur[o + 1] = g >> 4; blur[o + 2] = b >> 4; blur[o + 3] = 255
      }
    }
    const amount = 0.55
    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const i4 = (y * w + x) << 2
        const r = sb[i4], g = sb[i4 + 1], b = sb[i4 + 2]
        const br = blur[i4], bg = blur[i4 + 1], bb = blur[i4 + 2]
        src.data[i4] = clamp(Math.round(r + amount * (r - br)), 0, 255)
        src.data[i4 + 1] = clamp(Math.round(g + amount * (g - bg)), 0, 255)
        src.data[i4 + 2] = clamp(Math.round(b + amount * (b - bb)), 0, 255)
      }
    }
    ctx.putImageData(src, 0, 0)
  }

  async function copySnapshotBase64() {
    const shot = await capturePassport()
    if (!shot?.base64) return
    try { await navigator.clipboard.writeText(shot.base64); alert("Passport photo base64 copied.") }
    catch { console.log("Photo base64:", shot.base64.slice(0, 64) + "...") }
  }

  const allDone = currentStep >= steps.length
  const decided = finalPass !== null
  const liveNow = livenessScore
  const showPass = decided ? finalPass : (spoofScore >= cfg.PASS_THRESH_PAD && liveNow >= cfg.PASS_THRESH_LIVE)
  const activeStep = steps[currentStep]

  return (
    <div className="grid lg:grid-cols-5 gap-6">
      <div className="lg:col-span-3 space-y-3">
        <div className="relative rounded-2xl overflow-hidden card min-h-[360px]">
          <video ref={videoRef} className="w-full h-auto hidden" muted playsInline />
          <canvas ref={canvasRef} className="w-full h-auto block" />

          <PromptHUD
            phase={phase}
            calibPct={calibPct}
            cameraOn={cameraOn}
            cameraReady={cameraReady}
            faces={faceCount}
            done={allDone}
            finalPass={finalPass}
            stepKey={activeStep}
          />

          {!cameraOn && (
            <div className="absolute inset-0 grid place-items-center bg-slate-900/40 backdrop-blur">
              <div className="p-8 text-center">
                <div className="text-xl font-semibold mb-2">Webcam is off</div>
                <div className="text-slate-300 mb-4">Click start to begin liveness verification.</div>
                <button className="btn" disabled={!modelReady} onClick={startCamera}>
                  {modelReady ? "Start verification" : "Loading model…"}
                </button>
                {error && <div className="text-rose-400 mt-3 text-sm">{error}</div>}
              </div>
            </div>
          )}

          {cameraOn && (
            <div className="absolute bottom-0 left-0 right-0 p-4 backdrop-blur bg-slate-900/40">
              <div className="progress"><div style={{ width: `${holdPct}%` }} /></div>
              <div className="mt-2 flex items-center justify-between text-xs text-slate-300">
                <span>Step {Math.min(currentStep + 1, steps.length)}/{steps.length}</span>
                <span>Blinks: <b className="text-slate-100">{blinkCount}</b></span>
              </div>
            </div>
          )}
        </div>

        {/* Controls */}
        <div className="flex items-center gap-2">
          {!cameraOn ? (
            <button className="btn" disabled={!modelReady} onClick={startCamera}>Start</button>
          ) : (
            <>
              <button className="btn" onClick={restart}>Restart</button>
              <button className="btn-outline" onClick={stopCamera}>Stop</button>
              <button className="btn-outline" onClick={copySnapshotBase64}>Copy Passport Base64</button>
            </>
          )}
        </div>

        {/* Results */}
        {cameraOn && allDone && (
          <div className={`card p-4 border ${showPass ? "border-emerald-600" : "border-rose-600"}`}>
            <div className="flex items-center justify-between">
              <div>
                <div className="text-lg font-semibold">Result</div>
                <div className="text-slate-300 text-sm">Liveness score & anti-spoof checks</div>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold">{showPass ? "PASSED" : "FAILED"}</div>
                <div className="text-xs text-slate-400">{decided ? "Reviewed" : "Processing…"}</div>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4">
              <Metric label="Liveness Score" value={`${liveNow}/100`} ok={liveNow >= cfg.PASS_THRESH_LIVE} />
              <Metric label="Anti-Spoof Score" value={`${spoofScore}/100`} ok={spoofScore>=cfg.PASS_THRESH_PAD} />
              <Metric label="Depth Var (zRangeN)" value={(smooth.current.depthVar||0).toFixed(4)} ok={(smooth.current.depthVar||0) >= 0.02} />
              <Metric label="Blink Count" value={blinkCount} ok={blinkCount >= 2} />
            </div>
          </div>
        )}
      </div>

      {/* RIGHT COLUMN */}
      <div className="lg:col-span-2 space-y-4">

        {/* Checklist (bilingual) */}
        <div className="card p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-lg font-semibold">Checklist</div>
              <div className="text-slate-400 text-xs">Follow the prompts in random order</div>
            </div>
            <span className={`badge ${Object.values(stateRef.current.passed).filter(Boolean).length === 4 ? "badge-green" : "badge-yellow"}`}>
              {Object.values(stateRef.current.passed).filter(Boolean).length}/4 done
            </span>
          </div>
          <ul className="mt-3 space-y-2">
            {steps.map((s) => {
              const isCurrent = steps[currentStep] === s
              const passed = stateRef.current.passed[s]
              const data = INSTRUCTIONS[s]
              return (
                <li key={s} className={`flex items-center gap-3 p-3 rounded-xl border ${isCurrent ? "bg-slate-800/60 border-slate-700" : "border-slate-800"}`}>
                  <div className={`w-8 h-8 grid place-items-center rounded-full ${passed ? "bg-emerald-600/20" : isCurrent ? "bg-yellow-600/20" : "bg-slate-600/20"}`}>
                    <span className="text-lg">{data.icon}</span>
                  </div>
                  <div className="flex-1">
                    <div className="text-sm font-medium text-slate-200">{data.titleEn} <span className="text-slate-400">· {data.titleBn}</span></div>
                    <div className="text-[12px] text-slate-400 leading-tight">{data.en}</div>
                    <div className="text-[12px] text-slate-400 leading-tight">{data.bn}</div>
                  </div>
                  <span className={`badge ${passed ? "badge-green" : (isCurrent ? "badge-yellow" : "badge-red")}`}>
                    {passed ? "Done" : (isCurrent ? "Now" : "Wait")}
                  </span>
                </li>
              )
            })}
          </ul>
        </div>

        {/* Captured passport photo */}
        {cameraOn && allDone && (
          <div className="card p-4">
            <div className="flex items-center justify-between">
              <div className="text-lg font-semibold">Captured Photo (Passport)</div>
              <button className="btn-outline" onClick={async () => setPhoto((await capturePassport())?.data_url || null)}>
                Retake
              </button>
            </div>
            <div className="mt-3 rounded-xl overflow-hidden border border-slate-800 bg-white">
              {photo ? (
                <img src={photo} alt="passport" className="w-full h-auto block" />
              ) : (
                <div className="p-6 text-slate-600 text-sm">
                  Preparing a neutral snapshot… Please face the camera naturally.
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

/* -------- small components -------- */
function Metric({ label, value, ok }) {
  return (
    <div className="p-3 rounded-xl border border-slate-800 bg-slate-900/60">
      <div className="text-xs text-slate-400">{label}</div>
      <div className={`text-lg font-semibold ${ok ? "text-emerald-300" : "text-rose-300"}`}>{value}</div>
    </div>
  )
}

/* ---------- HUD ---------- */
function PromptHUD({ phase, calibPct, cameraOn, cameraReady, faces, done, finalPass, stepKey }) {
  const commonPanel = {
    initial: { opacity: 0, y: -12, scale: 0.98 },
    animate: { opacity: 1, y: 0, scale: 1, transition: { type: "spring", stiffness: 220, damping: 20 } },
    exit: { opacity: 0, y: -8, scale: 0.98, transition: { duration: 0.18 } },
  }
  const step = stepKey ? INSTRUCTIONS[stepKey] : null

  return (
    <div className="pointer-events-none absolute inset-0">
      <div className="absolute top-4 right-4 flex flex-col items-end gap-2">
        <AnimatePresence mode="wait">
          {phase === "align" && (
            <motion.div key="align" {...commonPanel} className="px-5 py-3 rounded-2xl bg-slate-900/80 backdrop-blur border border-white/10 shadow-xl">
              <div className="text-xl font-semibold text-slate-50">Align your face</div>
              <div className="text-slate-300 text-sm">{UI.align.en}</div>
              <div className="text-slate-400 text-xs">{UI.align.bn}</div>
            </motion.div>
          )}
          {phase === "calibrate" && (
            <motion.div key="calib" {...commonPanel} className="px-5 py-3 rounded-2xl bg-slate-900/80 backdrop-blur border border-white/10 shadow-xl">
              <div className="text-xl font-semibold text-slate-50">Calibrating…</div>
              <div className="text-slate-300 text-sm">{calibPct}%</div>
            </motion.div>
          )}
          {phase === "run" && !done && step && (
            <motion.div key={stepKey} {...commonPanel} className="px-5 py-4 rounded-2xl bg-slate-900/80 backdrop-blur border border-white/10 shadow-xl w-[min(92vw,360px)]">
              <div className="text-xl font-semibold text-slate-50 flex items-center gap-2">
                <span className="text-2xl" aria-hidden>{step.icon}</span>
                <span>{step.titleEn}</span>
              </div>
              <div className="mt-1 text-slate-200 text-sm">{step.en}</div>
              <div className="text-slate-300 text-xs">{step.bn}</div>
            </motion.div>
          )}
          {done && (
            <motion.div key="done" {...commonPanel} className={`px-5 py-4 rounded-2xl backdrop-blur border shadow-xl ${finalPass ? "bg-emerald-900/70 border-emerald-500/30" : "bg-rose-900/70 border-rose-500/30"}`}>
              <div className="text-xl font-semibold text-slate-50">{finalPass ? "Verification Passed" : "Check Failed — Try Again"}</div>
            </motion.div>
          )}
        </AnimatePresence>
        <div className="flex items-center gap-2">
          <div className="px-3 py-1 rounded-full bg-slate-900/70 border border-white/10 text-xs text-slate-200 shadow">{cameraOn ? (cameraReady ? "Cam: Ready" : "Cam: Starting…") : "Cam: Off"}</div>
          <div className="px-3 py-1 rounded-full bg-slate-900/70 border border-white/10 text-xs text-slate-200 shadow">Faces: {faces}</div>
        </div>
      </div>
    </div>
  )
}

export { }